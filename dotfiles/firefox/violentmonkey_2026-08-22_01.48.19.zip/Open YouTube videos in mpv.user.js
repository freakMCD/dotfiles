// ==UserScript==
// @name         Open YouTube videos in mpv
// @namespace    local
// @version      2.2
// @description  Open clicked YouTube video links in mpv
// @match        https://www.youtube.com/*
// @match        https://m.youtube.com/*
// @grant        none
// ==/UserScript==

(() => {
    "use strict";

    const youtubeHosts = new Set([
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "youtu.be",
    ]);

    function getVideoId(href) {
        let url;

        try {
            url = new URL(href, location.href);
        } catch {
            return null;
        }

        if (!youtubeHosts.has(url.hostname)) {
            return null;
        }

        let videoId = null;

        if (url.hostname === "youtu.be") {
            videoId = url.pathname.split("/").filter(Boolean)[0];
        } else if (url.pathname === "/watch") {
            videoId = url.searchParams.get("v");
        } else {
            const match = url.pathname.match(
                /^\/(?:shorts|live)\/([A-Za-z0-9_-]{11})/
            );

            videoId = match?.[1] ?? null;
        }

        return /^[A-Za-z0-9_-]{11}$/.test(videoId ?? "")
            ? videoId
            : null;
    }

    function findVideoLink(event) {
        const path = event.composedPath().filter(
            node => node instanceof Element
        );

        /*
         * Handle ordinary title and thumbnail links first.
         * If the clicked link is not a video link, preserve it.
         */
        const clickedLink = path.find(
            element => element.matches("a[href]")
        );

        if (clickedLink) {
            return getVideoId(clickedLink.href)
                ? clickedLink
                : null;
        }

        /*
         * The clicked element is not a link, as with the view count.
         * Climb through its containers and look for video links.
         */
        for (const container of path) {
            const videos = new Map();

            for (const link of container.querySelectorAll("a[href]")) {
                const videoId = getVideoId(link.href);

                if (videoId && !videos.has(videoId)) {
                    videos.set(videoId, link);
                }

                /*
                 * This container includes multiple videos, so it is too
                 * broad to determine which one the user intended.
                 */
                if (videos.size > 1) {
                    break;
                }
            }

            if (videos.size === 1) {
                return videos.values().next().value;
            }

            if (videos.size > 1) {
                return null;
            }
        }

        return null;
    }

    document.addEventListener("click", event => {
        // Preserve modified clicks and non-left clicks.
        if (
            event.button !== 0 ||
            event.ctrlKey ||
            event.shiftKey ||
            event.altKey ||
            event.metaKey
        ) {
            return;
        }

        const link = findVideoLink(event);

        if (!link) {
            return;
        }

        const url = new URL(link.href, location.href);

        event.preventDefault();
        event.stopImmediatePropagation();

        location.href =
            `mpv://open?url=${encodeURIComponent(url.href)}`;
    }, true);
})();